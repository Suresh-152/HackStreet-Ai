# Student-Chatbot
Get instant answers, guidance, and interactive conversations powered by advanced AI algorithms.
HackStreet AI aims to empower individuals and businesses by providing intelligent solutions, automating repetitive tasks, and enhancing decision-making through AI.
Maintain your personalized profile, upload photos, and manage your account securely.
Explore tutorials, resources, and tips to enhance your knowledge in coding, AI, and more.
Your data is safely stored locally, giving you full control over your information.

 Meet Our Team

Suresh Maity
Full-Stack Developer


Akash Kajla
Backend Developer


Patatri Mukherjee
Front-end Developer


Koyel Sultana
Front-end Developer